function myfunction()
{
    var x=document.getElementById('name').value;
    var y=document.getElementById('email').value;
    var z=document.getElementById('password').value;

    //alert(z);
    if(x==''||y==''||z=='')
    {
        alert("Please Enter All Details")
    }
    else
    {
        alert("Welcome Back")
    }
}