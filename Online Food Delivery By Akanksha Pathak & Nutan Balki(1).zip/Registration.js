

function myfun()
{
    var x=document.getElementById('name').value;
    var y=document.getElementById('email').value;
    var z=document.getElementById('password').value;
    var b=document.getElementById('Rpassword').value;
    var a=document.getElementById('address').value;


    //alert(z);
    if(x==''||y==''||z==''||a==''||b=='')
    {
      alert("Please Enter All Information") 
    }
    else if(a!=b){
               alert("enter matching Password")
    }
    else
    {
        alert("Welcome to FoodLy Family!!!")
    }
}